package system;

public interface  LoginObserver {
	void onLoginSuccess();
}
